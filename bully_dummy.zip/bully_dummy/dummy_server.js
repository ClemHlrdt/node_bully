var zerorpc = require("zerorpc");

var server = new zerorpc.Server({
    hello: function(name, reply) {
        reply(null, "Hello, " + name);
    },
    sayHi: function(value, reply){
        reply(null, "You said : " + value)
    }, 
    streaming_range: function(from, to, step, reply) {
        for(var i=from; i<to; i+=step) {
            reply(null, i, i + step < to);
        }
    }
});

server.bind("tcp://0.0.0.0:4242");
