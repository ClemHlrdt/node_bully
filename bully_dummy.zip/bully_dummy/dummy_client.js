var zerorpc = require("zerorpc");

var client = new zerorpc.Client();
client.connect("tcp://127.0.0.1:4242");

client.invoke("hello", "RPC", function(error, res, more) {
    console.log(res);
});

client.invoke("sayHi", "I am the best client", function(error, res, more){
    console.log(res);
})

client.invoke("streaming_range", 10, 20, 2, function(error, res, more) {
    console.log(res);
});

